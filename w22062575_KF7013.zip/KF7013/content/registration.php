<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" sizes="180x180" href="/KF7013/assets/images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/KF7013/assets/images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/KF7013/assets/images/favicon/favicon-16x16.png">
    <link rel="manifest" href="/KF7013/assets/images/favicon/site.webmanifest">
    <link rel="mask-icon" href="/KF7013/assets/images/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="theme-color" content="#ffffff">  
    <link rel="stylesheet" href="/KF7013/assets/stylesheets/styles.css" />
    <title>Registration - Tooneland</title>           
</head>


<body>
     <!-- this php is for checking logged-in status to enable the navbar as javascript cannot directly access the httponly and secure cookie -->
    <?php
    session_start();
    echo '<script type="text/javascript">';
    if (isset($_SESSION['logged-in']) && $_SESSION['logged-in'] === true) {
        echo 'var isLoggedIn = true;';
    } else {
        echo 'var isLoggedIn = false;';
    }
    echo '</script>';
    ?>

    <header class="header_container">

        <!-- Navigation bar -->

        <nav class="navbar">
            <a href="index.php"><img src="/KF7013/assets/images/logo.png" alt="logo"></a>
            <ul class="navbar_list">
            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>

    </header>


    <!-- Main Page --> 
    <div class="page_container">

        <div class="banner">
            <img src="/KF7013/assets/images/cover.webp" alt="event1">
        </div>
        <div class="booking-redir">
            <h2> Register you account </h2>
            <h3> Book Now. Pay Later </h3>
            <p> Only registered users can book the tickets. <br> Please make sure to enter your details correctly </p>
        </div>

        <!-- Registration form -->

        <div class="booking-form">
            <form id="userForm" method="post" action="submit_user.php">
                First Name: <input type="text" name="firstname" required><br>
                
                Last Name: <input type="text" name="surname" required><br>
                
                DOB: <input type="date" name="dob" id="dob" required><br>

                <label for="gender">Select your gender:</label>
                <select name="gender" id="gender">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select><br>

                Email ID: <input type="email" name="username" required><br>
                Confirm Email ID: <input type="email" name="confirm_email" required><br>

                Password: <input type="password" name="password" required minlength="8"><br>
                Confirm Password: <input type="password" name="confirm_password" required minlength="8"><br>

                Address: <input type="text" name="address" required><br>
                City: <input type="text" name="city" required><br>
                Postcode: <input type="text" name="postal_code" required><br>


                <input type="submit" value="Create User">

            </form>            
        </div>

        <!-- Link to login page -->
        <div class="booking-redir">
            <h3></h3><a href="logon.php"> Already a member? Sign-in Here!</a><h3></h3>
        </div>
    </div>

    <!-- Footer -->
    
    <footer class="footer">

        <div class="footer-text">
            <div class="footer-section">
                <h4>Browse</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="eventslist.php">All Events</a></li>
                    <li><a href="credits.php">Credits</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Address</h4>
                <p>The Toone Park, <br>TL7 7AR, <br>Toonland</p>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>+44 78945 12356 <br> tooneevents@email.com</p>
            </div>
        </div>
        <div class="footer-img">
            <a href="index.php"><img src="/KF7013/assets/images/logodark.png" alt="logo"></a>
        </div>
    </footer>

    <script src="/KF7013/assets/scripts/form-validation.js"></script>
    <script src="/KF7013/assets/scripts/scripts.js"></script>
</body>
</html>
